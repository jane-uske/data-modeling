import * as DomainController from './domain';
import * as ModelController from './model';
import * as modelHisController from './modelHis';
import * as BusinessObjectController from './businessObject';
export default {
  DomainController,
  ModelController,
  modelHisController,
  BusinessObjectController,
};
