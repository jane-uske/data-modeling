import '@umijs/max/typings';
